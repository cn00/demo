#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="DragAndDropMethods.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor
{
    /// <summary>
    /// This class is due to undergo refactoring.
    /// </summary>
    public enum DragAndDropMethods
    {
        /// <summary>
        /// Not yet documented.
        /// </summary>
        Reference = 1,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Move = 2,

        /// <summary>
        /// Not yet documented.
        /// </summary>
        Copy = 3
    }
}
#endif